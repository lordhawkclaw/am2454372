/* 
 * Anthony Muller
 * January 15, 2014
 * Calculate how many calories you ate
 */

//system libraries
#include <iostream>
using namespace std;

//global constants
const int PERC=75;//calories per cookie
//functional prototypes

//execution starts here
int main(int argc, char** argv) {
//declare variables
    int cooks,cals;
    //display purpose
    cout<<"This program calculates how many calories you have consumed if you are eating cookies"<<endl;
    //get how many cookies
    cout<<"How many cookies have you eaten?"<<endl;
    cin>>cooks;
    //calculate how many calories
    cals=cooks*PERC;
    //display results
    cout<<"You have taken in "<<cals<<" Calories worth of cookies."<<endl;
    
    return 0;
}

