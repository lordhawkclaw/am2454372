/* 
 * Anthony Muller
 * January 15, 2014
 * calculate miles per gallon
 */

//system libraries
#include <iostream>
using namespace std;

//global constants

//function prototypes

//execution starts here
int main(int argc, char** argv) {
//declare variables
    int miles,galls,mpg;
    cout<<"This program calculates Miles Per Gallon (MPG)"<<endl;
    cout<<"Enter how many gallons of gas your gas tank can hold"<<endl;
    cin>>galls;
    cout<<"Enter how many miles you can travel on a full tank of gas"<<endl;
    cin>>miles;
    mpg=miles/galls;
    cout<<"You get "<<mpg<<" miles per gallon"<<endl;
    return 0;
}

