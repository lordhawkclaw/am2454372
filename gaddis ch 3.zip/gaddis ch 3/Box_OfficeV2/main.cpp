/* 
 * Anthony Muller
 * January 15 2014
 * Calculate gross and net profit for a theatre
 */

//system libraries
#include <iostream>
using namespace std;

//global constants
const int ADULT=6;
const int CHILD=3;

//function prototypes

//execution starts here
int main(int argc, char** argv) {
//declare variables
    string movie;
    int ATic,CTic,gross,net,dist;
    //purpose displayed
    cout<<"This Program will calculate theatre profits for the night for a particular movie"<<endl;
    //how many tickets?
    cout<<"How many Adult tickets were sold?"<<endl;
    cin>>ATic;
    cout<<"How man Child tickets were sold?"<<endl;
    cin>>CTic;
    //calculate the amounts
    gross=(ATic*ADULT)+(CTic*CHILD);
    net=gross*0.2;
    dist=gross-(gross*0.2);
    //Name of movie?
    cout<<"What is the name of the movie?"<<endl;
    cin>>movie;
    //display results
    cout<<"Movie Name - "<<movie<<endl
        <<"Adult Tickets sold - "<<ATic<<endl
        <<"Child Tickets sold - "<<CTic<<endl
        <<"Gross Box Office Profit -  $"<<gross<<endl
        <<"Net Box Office Profit -  $"<<net<<endl
        <<"Amount paid to Distributor -  $"<<dist<<endl;
    return 0;
}

