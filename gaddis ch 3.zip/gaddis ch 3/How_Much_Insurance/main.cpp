/* 
 * Anthony Muller
 * January 15, 2014
 * calculate the minimum insurance you shoul have
 */

//system libraries
#include <iostream>
using namespace std;

//global constants

//function prototypes

//execution begins here
int main(int argc, char** argv) {
//declare variables
    int cost,insr;
    cout<<"This program calculate how much home insurance you need"<<endl;
    cout<<"How much does your house cost to rebuild?"<<endl;
    cin>>cost;
    insr=cost*0.8;
    cout<<"You should insure your home for $"<<insr<<endl;
    return 0;
}

