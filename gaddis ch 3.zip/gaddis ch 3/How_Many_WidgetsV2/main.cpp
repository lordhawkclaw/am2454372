/* 
 * Anthony Muller
 * January 15, 2014
 * calculate how many widgets are on a pallet 
 */

//system libraries
#include <iostream>
using namespace std;

//global constants
const int WIDGWT=9.2;
//function prototypes 

int main(int argc, char** argv) {
//declare variables
    int wgt,pwgt,wdgts;
    //display purpose
    cout<<"This Program calculates how many widgets are stacked on a pallet, based on weights."<<endl;
    //get inputs for weights 
    cout<<"How much does the pallet weight without anything on it?"<<endl;
    cin>>pwgt;
    cout<<"How much does the pallet weight with the widgets stacked on it?"<<endl;
    cin>>wgt;
    //calculate the how many widgets are on pallet
    wdgts=(wgt-pwgt)/WIDGWT;
    //display results
    cout<<"There are "<<wdgts<<" Widgets on the pallet/s"<<endl;
    return 0;
}

