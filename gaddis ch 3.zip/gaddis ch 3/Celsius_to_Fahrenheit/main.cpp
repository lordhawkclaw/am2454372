/* 
 * Anthony Muller
 * January 18, 2014
 * Convert Celsius to fahrenheit 
 */

//system libraries
#include <iostream>
using namespace std;

//global constants

//function prototypes

//execution begins here
int main(int argc, char** argv) {
//declare variables
    float cel,fah,cvnCF;
    //display purpose
    cout<<"This program will convert Celsius to Fahrenheit"<<endl;
    //get fahr
    cout<<"Enter the degrees Celsius"<<endl;
    cin>>cel;
    fah=(1.8*cel)+32;
    cout<<cel<<" degrees Celsius converted to Fahrenheit is "<<fah<<" degrees"<<endl;
    return 0;
}

