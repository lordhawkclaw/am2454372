/* 
 * Anthony Muller
 * January 18, 2014
 * Calculate the average rainfall
 */

//system libraries
#include <iostream>
using namespace std;

//global constants

//function prototypes

//execution begins here
int main(int argc, char** argv) {
//declare variables
    float rf1,rf2,rf3,avg;
    string m1,m2,m3;
    //display purpose
    cout<<"This program will calculate the average rain fall for three months."<<endl;
    //get inputs
    cout<<"What is the name of the first month?"<<endl;
    cin>>m1;
    cout<<"How many inches of rain were there in "<<m1<<endl;
    cin>>rf1;
    cout<<"What is the name of the second month?"<<endl;
    cin>>m2;
    cout<<"How many inches of rain were there in "<<m2<<endl;
    cin>>rf2;
    cout<<"What is the name of the third month?"<<endl;
    cin>>m3;
    cout<<"How many inches of rain were there in "<<m3<<endl;
    cin>>rf3;
    //calculate the average rainfall
    avg=(rf1+rf2+rf3)/3;
    //display results
    cout<<"The average rainfall for "<<m1<<","<<m2<<","<<m3<<" is "<<avg<<" inches."<<endl;
    
    return 0;
}

