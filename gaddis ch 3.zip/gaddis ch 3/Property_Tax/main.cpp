/* 
 * Anthony Muller
 * January 19, 2014
 * Calculate the property tax
 */

//system libraries
#include <iostream>
#include <iomanip>
using namespace std;

//global constants

//function prototypes

//execution begins here
int main(int argc, char** argv) {
//declare variables
    float acres,ass,proTax;
    //display purpose
    cout<<"This program will calculate the assessment value and property tax."<<endl;
    //get input
    cout<<"What is the value of your property? ($)"<<endl;
    cin>>acres;
    //calculate it all
    ass=acres*0.6;
    proTax=(ass/100)*0.64;
    //display results
    cout<<setprecision(2)<<fixed<<endl;
    cout<<"The assesment value on your property is $"<<ass<<endl; 
    cout<<"The property tax on your property is $"<<proTax<<endl;
    //end
    return 0;
}

