/* 
 * Anthony Muller
 * January 18,2014
 * Calculate the costs of an automobile
 */

//system libraries
#include <iostream>
using namespace std;

//global constants

//function prototypes

//execution begins here
int main(int argc, char** argv) {
//declare variables
    float loPay,insur,gas,oil,tires,maint,moCost,anCost;
    //display purpose
    cout<<"This Program calculates the monthly and annual cost of an automobile"<<endl;
    //get variable inputs
    cout<<"How much is your monthly loan payment? ($)"<<endl;
    cin>>loPay;
    cout<<"How much is your monthly insurance payment? ($)"<<endl;
    cin>>insur;
    cout<<"How much is your monthly gas costs? ($) "<<endl;
    cin>>gas;
    cout<<"How much is your monthly oil costs? ($) "<<endl;
    cin>>oil;
    cout<<"How much is your monthly tire costs? ($) "<<endl;
    cin>>tires;
    cout<<"How much is your monthly maintenance costs? ($) "<<endl;
    cin>>maint;
    //calculate monthly cost
    moCost=loPay+insur+gas+oil+tires+maint;
    anCost=moCost*12;
    //output results
    cout<<"The Monthly cost of your automobile is $"<<moCost<<endl;
    cout<<"The Annual cost of your automobile is $"<<anCost<<endl;

    
    return 0;
}

