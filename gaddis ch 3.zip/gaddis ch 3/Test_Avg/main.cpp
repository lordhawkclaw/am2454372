/* 
 * Anthony Muller
 * January 15, 2014
 * Calculate avg of five test scores
 */

//system libraries
#include <iostream>
#include <iomanip>
using namespace std;

//global constants

//function prototypes

//exectution begins here
int main(int argc, char** argv) {
//declare variables
    int t1,t2,t3,t4,t5,avg;
    cout<<"this program calculates the average test score of five tests."<<endl;
    cout<<"Enter Test Score One"<<endl;
    cin>>t1;
    cout<<"Enter Test Score Two"<<endl;
    cin>>t2;
    cout<<"Enter Test Score Three"<<endl;
    cin>>t3;
    cout<<"Enter Test Score Four"<<endl;
    cin>>t4;
    cout<<"Enter Test Score Five"<<endl;
    cin>>t5;
    avg=(t1+t2+t3+t4+t5)/5;
    cout<<"The average of the five test scores is "<< fixed << setprecision(1) <<avg<<endl;
    return 0;
}

