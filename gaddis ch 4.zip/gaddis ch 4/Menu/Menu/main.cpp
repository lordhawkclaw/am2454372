/* 
 * Anthony Muller
 * January 16, 2014
 * 1 - order numbers from greatest to least
 * 2 - convert a number to roman numeral
 * 3 - Find the magic date
 */

//system libraries
#include <cstdlib>
#include <iostream>
using namespace std;

//global constants

//function prototypes

//execution starts here
int main(int argc, char** argv) {
    //General Menu Format
    bool loop=true;
    do{
        //Display the selection
        cout<<"Type 1 to solve problem 1"<<endl;
        cout<<"Type 2 to solve problem 2"<<endl;
        cout<<"Type 3 to solve problem 3"<<endl;
        cout<<"Type 4 to solve problem 3 again"<<endl;
        cout<<"Type anything else to quit with no solutions."<<endl;
        //Read the choice
        char choice;
        cin>>choice;
        //Solve a problem that has been chosen.
        switch(choice){
                case '1':{
                   //declare variables
                    int n1,n2,grt,lst;
                    cout<<"This program puts two numbers in order from greatest to smallest"<<endl;
                    cout<<"Enter Number one"<<endl;
                    cin>>n1;
                    cout<<"Enter Number two"<<endl;
                    cin>>n2;
                    //If
                    if (n1>n2){
                        cout<<n1<<" = Max ";
                        cout<<n2<<" = Min"<<endl;;
                    }else{
                        cout<<n2<<" = Max ";
                        cout<<n1<<" = Min"<<endl;
                    }
                    break;
                }
                case '2':{
                    //declare variables
                    int num;
                    cout<<"This Program will convert numbers into roman numerals"<<endl;
                    cout<<"Enter a number between 1 and 10"<<endl;
                    cin>>num;
                    //if
                    switch(num){
                             case 1:cout<<"I"<<endl;
                            break;
                             case 2:cout<<"II"<<endl;
                            break;
                             case 3:cout<<"III"<<endl;
                            break;
                             case 4:cout<<"IV"<<endl;
                            break;
                             case 5:cout<<"V"<<endl;
                            break;
                             case 6:cout<<"VI"<<endl;
                            break;
                             case 7:cout<<"VII"<<endl;
                            break;
                             case 8:cout<<"VIII"<<endl;
                            break;
                             case 9:cout<<"IX"<<endl;
                            break;
                             case 10:cout<<"X"<<endl;
                            break;
                        default:cout<<"you failed to enter a number 1-10"<<endl;
                    }      
                    break;
                }
                case '3':{
                    //declare variables
                    int mth,day,yr;
                    cout<<"This program finds the magic!!"<<endl;
                    cout<<"Enter a month in numeric form"<<endl;
                    cin>>mth;
                    cout<<"Enter the Day"<<endl;
                    cin>>day;
                    cout<<"Enter the year (two digits)"<<endl;
                    cin>>yr;
                    break;
                }
                case '4':{
                    
                    break;
                }
                default:{
                    
                        break;
                }
        };
    }while(loop);//Upper do-while
    return 0;
}

