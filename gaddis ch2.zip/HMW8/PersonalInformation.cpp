/*
Anthony Muller
January 9, 2014
Display indormaition on multiple lines with one cout
*/
//system libraries
#include <iostream>
using namespace std;

//global constants

//functional prototypes

//execution begins here
int main() {
//declare variables

//say this stuff here
cout<<"Anthony Muller"
    << "1234 Cheese street, NoWhere, California 12345"
    << "9515315156"
    << "Computer Engineering Major \n";
    
	return 0;
}