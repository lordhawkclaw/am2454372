//Anthony Muller
//January 8, 2014
//calculate how much the ocean will rise 

//system libraries
#include <iostream>
using namespace std;

//global constants
const float rise=1.5;

//funtioning prototypes

//execution starts here
int main() {

//declare variables
float clevel,fyrs,syrs,tyrs;//current level,fiveyears,sevenyears ect
cout<<"What is the current ocean level in millimeters";
cin>>clevel;
fyrs=rise*5+clevel;
syrs=rise*7+clevel;
tyrs=rise*10+clevel;
cout<<"The ocean will be "
<<fyrs<<" millimeters in five years"<<endl;
cout<<"The ocean will be "
<<syrs<<" millimeters in seven years"<<endl;
cout<<"The ocean will be "
<<tyrs<<" millimeters in ten years"<<endl;
	return 0;
}