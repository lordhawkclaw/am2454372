/*
Anthony Muller
January 8,2014
Draw a triangle
*/

//system libraries
#include <iostream>
using namespace std;

//Funtional Prototypes

//execution starts here
int main() {
cout<<"   *   "endl;
cout<<"  ***  "endl;
cout<<" ***** "endl;
cout<<"*******"endl;
	return 0;
}