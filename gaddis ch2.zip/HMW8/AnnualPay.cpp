/*
Anthony Muller
January 8, 2014
Calculate Anual Pay
*/
//System Libraries

//Global Constants

//Function prototypes

//Execution Starts here
#include <iostream>
using namespace std;

int main() {
//declare Variables
float payAmo,payper,annpay;
//Input amount of pay per pay period
cout<<" how much do you earn per pay period? "<<endl;
cin>>payAmo;
cout<<" How many Pay periods do you have in a year? "<<endl;
cin>>payper;
annpay=payAmo*payper;
//annual pay is calculated
cout<<"You will make"
  <<annpay<<" dollars per year "<<endl;
	return 0;
}