//Anthony Muller
//January 8, 2014
// Average of variables

//system libraries
#include <iostream>
using namespace std;

//Global constants

//funtional prototypes

//execution starts here
int main() {

//declare variables
float one,two,three,four,five,total,av;
cout<<"1"<<endl;
cin>>one;
cout<<"2"<<endl;
cin>>two;
cout<<"3"<<endl;
cin>>three;
cout<<"4"<<endl;
cin>>four;
cout<<"5"<<endl;
cin>>five;
//average the numbers
total=one+two+three+four+five;
av=total/5;
cout<<"The average is"
<<av<<endl;
	return 0;
}