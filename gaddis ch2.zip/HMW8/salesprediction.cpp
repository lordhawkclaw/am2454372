/*
Anthony Muller
January 9, 2014
determine the amount of money made by the east coast division of a company
*/

//system libraries
#include <iostream>
using namespace std;

//global constants

//functional prototypes

//execution begins here
int main() {

//declare variables
int ecd,yrsls;

cout<<"What is the total sales for the company this year?"<<endl;
cin>>yrsls;
//calulate how much the east coast divion made
ecd=yrsls*0.62;
cout<<"The east coast division made "<<ecd<<endl;
//end code 
	return 0;
}