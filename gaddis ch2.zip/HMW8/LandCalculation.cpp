/*
 Anthony Muller
 January 7, 2014
 Convert feet to acres
*/

//system libraries 
#include <iostream>
using namespace std;

//global constants

//function prototypes

//execution starts here
int main() {
//declare variables
float acres,SqFt;
cout<<"How many square feet?"<<endl;
cin>>SqFt;
acres=SqFt/43560;
//calculate how many acres
cout<<"There are"
<<acres<<"acres"<<endl;
	return 0;
}