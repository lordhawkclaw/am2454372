/*
Anthony Muller
January 9, 2014
Calculate Sales tax
*/

//system libraries
#include <iostream>
using namespace std;

//global constants
const int SST=0.04;//State sales tax
const int CST=0.02;//county sales tax

//functional prototypes

//execution starts here
int main() {

//declare variables
int purc,tax;

cout<<"What was the amount of the purchase in dollars?"<<endl;
//input purchase amount
cin>>purc;
tax=(purc*SST)+(purc*CST);
//output the tax
cout<<"the total tax on your purchase is "<<tax<<endl;
//end of code
	return 0;
}