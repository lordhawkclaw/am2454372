//Anthony Muller
//January 8, 2014
//Calculate miles per gallon

//system libraries
#include <iostream>
using namespace std;

//global constants

//functional prototypes

//execution starts here
int main() {

//declare variables
float galls,miles,mpg;
cout<<"What size in gallons is your gas tank?"<<endl;
cin>>galls;
cout<<"How many miles can you drive without refueling?"endl;
cin>>miles;
mpg=galls/miles;
cout<<"You have "
<<mpg<<" Miles per gallon"<<endl;
	return 0;
}