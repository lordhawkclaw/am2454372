//Anthony Muller
//January 8, 2014
//Add two numbers

//System Libraries
#include <iostream>
using namespace std;

//global constants

//functional prototypes

//execution starts here
int main() {

//declare variables
float one,two,total;
cout<<"1"<<endl;
cin>>one;
cout<<"2"<<endl;
cin>>two;
//calculation here
total=one+two;
cout<<"The Total is"
<<total<<endl;
	return 0;
}